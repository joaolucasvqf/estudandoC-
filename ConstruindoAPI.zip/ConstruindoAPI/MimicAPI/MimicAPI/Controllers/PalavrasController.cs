﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MimicAPI.Database;
using MimicAPI.Helpers;
using MimicAPI.Models;
using MimicAPI.Repositories.Contracts;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MimicAPI.Controllers
{
    [Route("api/palavras")]
    public class PalavrasController : ControllerBase
    {
        private readonly IPalavraRepository _repository;
        public PalavrasController(IPalavraRepository repository)
        {
            _repository = repository;
        }
        /// <summary>
        /// Crud com todas as palavras cadastradas no banco
        /// </summary>
        /// <param name="data">data=yyyy-mm-dd</param>
        /// <param name="pagNum">Número da página</param>
        /// <param name="RegPerPag">Quantidade de registros por página</param>
        /// <returns>Json</returns>
        [Route("")]
        [HttpGet]
        public ActionResult ObterPalavras([FromQuery]PalavraUrlQuery query)
        {
            var item = _repository.ObterPalavras(query);
            if (query.PagNum > item.Paginacao.PagesTotal)
            {
                return NotFound();
            }
            
            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(item.Paginacao));
            
            return Ok(item.ToList());
            //Outra opção de retorno
            //return new JsonResult( _banco.Palavras );
        }
        /// <summary>
        /// Pesquisa por uma palavra específica
        /// </summary>
        /// <param name="id">Id da palavra a ser pesquisada</param>
        /// <returns>Json</returns>
        [Route("{id}")]
        [HttpGet]
        public ActionResult Obter(int id)
        {
            var obj = _repository.Obter(id);

            if (obj == null)
                return NotFound();

            return Ok(obj);
        }
        /// <summary>
        /// Cadastrar uma nova palavra
        /// </summary>
        /// <param name="palavra">Palavra a ser cadastrada</param>
        /// <returns>OkHttpResponse</returns>
        [Route("")]
        [HttpPost]
        public ActionResult Cadastrar([FromBody]Palavra palavra)
        {
            _repository.Cadastrar(palavra);

            return Created($"/api/palavras/{palavra.Id}", palavra);
        }
        /// <summary>
        /// Request para atualizar uma palavra
        /// </summary>
        /// <param name="id"></param>
        /// <param name="palavra">Palavra a ser atualizada</param>
        /// <returns>OkHttpResponse</returns>
        [Route("{id}")]
        [HttpPut]
        public ActionResult Atualizar(int id, [FromBody]Palavra palavra)
        {
            var obj = _repository.Obter(id);
            if (obj == null)
                return NotFound();

            palavra.Id = id;
            _repository.Atualizar(palavra);
            
            return Ok();
        }
        /// <summary>
        /// Request para deleção
        /// </summary>
        /// <param name="id">Id da paravra a ser deletada</param>
        /// <returns>OkHttpResponse</returns>
        [Route("{id}")]
        [HttpDelete]
        public ActionResult Deletar(int id)
        {
            var palavra = _repository.Obter(id);

            if (palavra == null)
                return NotFound();

            _repository.Deletar(id);
            
            return NoContent();
        }
    }
}
